/************************** SVN Revision Information **************************
 **    $Id: get_invmat.c 4163 2017-12-07 21:14:35Z ebriggs $    **
******************************************************************************/
 
#include <float.h>
#include <stdio.h>
#include "main.h"
#include "prototypes_on.h"
#include "init_var.h"

/* 
   	output: matB = (matB)^-1
*/





void get_invmat(double *matB)
{
    int numst = ct.num_states;
    int info;
    char uplo = 'l';

    int ione = 1;
    int myrow;
    char *char_fcd1;



    myrow = pct.scalapack_myrow;

    /* If I'm in the process grid, execute the program */
    if (myrow != -1)
    {
        /* Compute the Cholesky decomposition of matB */
        char_fcd1 = &uplo;
        pdpotrf(char_fcd1, &numst, matB, &ione, &ione, pct.desca, &info);
        if (info != 0)
        {
            printf(" pdpotrf in get_invmat.c, output info=%d\n", info);
            fflush(NULL);
            exit(0);
        }
        /* now get the inverse */
        pdpotri(char_fcd1, &numst, matB, &ione, &ione, pct.desca, &info);
        if (info != 0)
        {
            printf(" pdpotri, output info=%d\n", info);
            fflush(NULL);
            exit(0);
        }
    }

    my_barrier();


}
