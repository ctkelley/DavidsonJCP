/************************** SVN Revision Information **************************
 **    $Id: change_states_crds.c 3145 2015-08-12 18:06:55Z luw $    **
******************************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include "prototypes_on.h"
#include "init_var.h"


/* Reads and parses the input control file */
void change_states_crds(STATE * states)
{

    int ion, ist;

    /* Coordinates and species type for each ion. */
    for (ist = 0; ist < ct.num_states; ist++)
    {

        ion = states[ist].atom_index;

        if (ct.ions[ion].movable)
        {

            states[ist].crds[0] = ct.ions[ion].crds[0];
            states[ist].crds[1] = ct.ions[ion].crds[1];
            states[ist].crds[2] = ct.ions[ion].crds[2];


        }                       /* end if */

    }


}
